# slides-frontend
Frontend do sistema de slides.
